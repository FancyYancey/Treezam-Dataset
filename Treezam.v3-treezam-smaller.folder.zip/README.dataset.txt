# Treezam > Treezam Smaller
https://universe.roboflow.com/ai-camp-vsyrn/treezam

Provided by a Roboflow user
License: CC BY 4.0

